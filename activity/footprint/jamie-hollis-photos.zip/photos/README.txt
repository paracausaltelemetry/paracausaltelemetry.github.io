Operation Heatmap - photo pack

Six images recovered from LCpl Jamie Hollis's public posts. All are DESIGNED
RECONSTRUCTIONS for training: the pictures are drawn, but the EXIF metadata is
real and is the point of the exercise.

Try:  exiftool -gpslatitude -gpslongitude -datetimeoriginal -model *.jpg
Or:   exiftool -ee -n IMG_20260529_064112.jpg

Everything about Jamie is fictional. Do not run lookups against real people or
real services with any of this data.
